<html>
<body>

    Welcome <?php $valor1=$_GET["Valor1"]; $valor2=$_GET["Valor2"]; 
        $resultado= $valor1 + $valor2;
        echo $resultado
    ?><br>
   

</body>
</html>